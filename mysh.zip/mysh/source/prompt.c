#include <stdlib.h>
#include <stdio.h>

#include "../header/prompt.h"

void prompt_shell() {
	
	printf("\033[36;1mmysh: \033[37;2m");

}
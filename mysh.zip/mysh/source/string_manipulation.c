#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "../header/string_manipulation.h"

#define ARG_LENGTH 30

int add_word(char **array, const char *new_word, int nb_words);

/**
 * @brief Removes the '\n' caracters at the end of the user's input string
 * 
 * @param str The string to modify
 * @param len The max length of the string
 */
void remove_enter_keypress(char *str, int len) {

	int found = 0;
	int i = 0;

	while(i < len && !found) {

		if(str[i] == '\n') {

			str[i] = '\0';
			found = 1;

		}

		++i;

	}

}

/**
 * @brief Exploded a string into sub-strings, separated by the 'del' caracter
 * 
 * @param str The string to split
 * @param del The caracters which delimits the different sections
 * @return int The number of arguments
 */
char** explode_string(const char *str, char del) { // TODO Maybe return int ??

	int nb_words = 0;
	char** array = (char**)malloc(0);

	if(array == NULL) {

		free(array);

	} else {

		int len = strlen(str);
		int i = 0, j = 0;

		char arg[ARG_LENGTH];

		while(i <= len) {

			if(str[i] == del || str[i] == '\0') {

				arg[i] = '\0';
				if(j != 0) { // If arg is not empty

					++nb_words;
					if(add_word(array, arg, nb_words)) {
						while(i < len && str[i] == del) {
							++i;
						}
						--i;
						j = 0;
					} else {
						free_array(array);
						return NULL;
					}
				}

			} else {

				arg[j] = str[i];
				++j;

			}

			++i;

		}
		++nb_words;
		array = (char**)realloc(array, sizeof(char*)*nb_words);
		if(array == NULL) {
			free_array(array);
			exit(EXIT_FAILURE);
		}
		array[nb_words-1] = NULL;

	}

	return array;

}

/**
 * @brief Adds a word into a newly created place inside the returned string array
 * 
 * @param array The string array on which we want to add a word
 * @param new_word The word we want to add
 * @param nb_words The number of WANTED words (new word counted)
 * @return int 0 if something went wrong, else 1
 */
int add_word(char **array, const char *new_word, int nb_words) {

	int sort = 1;

	array = (char**)realloc(array, nb_words * sizeof(char*));

	if(array == NULL) {

		free_array(array);
		sort = 0;

	} else {
		
		array[nb_words - 1] = (char*)malloc(ARG_LENGTH * sizeof(char));
		array[nb_words - 1][0] = '\0';

		if(array[nb_words - 1] == NULL) {
			free_array(array);
			sort = 0;
		}

		strcpy(array[nb_words - 1], new_word);

	}

	return sort;

}

/**
 * @brief Frees the malloc used for the exploded string
 * 
 * @param array The string array to free
 */
void free_array(char **array) {

	array = (char**)realloc(array, 0); // Am I a genius ??

	free(array);

}

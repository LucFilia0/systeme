#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

#include "../header/execute.h"
#include "../header/string_manipulation.h"

int execute_command(const char *cmd) {

	char **exploded_cmd = explode_string(cmd, ' ');

	if(exploded_cmd == NULL) {
		free(exploded_cmd);
		exit(EXIT_FAILURE);
	}

	if(fork() > 0) {
		wait(NULL);
	} else {
		int status = execvp(exploded_cmd[0], exploded_cmd);
		printf("%d\n", status);
	}
	free_array(exploded_cmd);

}

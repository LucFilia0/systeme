#ifndef EXECUTE
#define EXECUTE

int execute_command(const char *cmd);

#endif
#ifndef PROMPT
#define PROMPT

void prompt_shell();

#endif
#ifndef STRING_MANIPULATION
#define STRING_MANIPULATION

void remove_enter_keypress(char *str, int len);

char** explode_string(const char *str, char del);

void free_array(char **array);

#endif

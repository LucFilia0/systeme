# MySH

My own shell on Linux :eyes:

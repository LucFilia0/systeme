#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "header/prompt.h"
#include "header/execute.h"
#include "header/string_manipulation.h"

#define CMD_LENGTH 100
#define ARG_LENGTH 30

int main(int argc, char **argv) {

	int quit = 0;

	char cmd[CMD_LENGTH];

	while(!quit) {

		cmd[0] = '\0';
		prompt_shell();
		fgets(cmd, CMD_LENGTH, stdin);
		remove_enter_keypress(cmd, CMD_LENGTH);
		
		if(strcmp(cmd, "exit") == 0) {

			quit = 1;

		} else {

			execute_command(cmd);
			
		}

	}

	exit(EXIT_SUCCESS);

}
